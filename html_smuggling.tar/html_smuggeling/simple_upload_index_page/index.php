<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set upload limits
ini_set('upload_max_filesize', '100M');
ini_set('post_max_size', '101M');
ini_set('max_execution_time', '300');

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
    $result = handleUpload();
    if (isset($result['redirect'])) {
        header('Location: ' . $result['redirect']);
        exit;
    }
}

// Get current directory files
$files = getDirectoryFiles();
$stats = getFileStats($files);

// Function to handle file upload
function handleUpload() {
    $uploadDir = '.';
    $maxFileSize = 100 * 1024 * 1024; // 100MB
    
    if (!isset($_FILES['files']) || $_FILES['files']['error'][0] === UPLOAD_ERR_NO_FILE) {
        return ['success' => false, 'message' => 'No files selected'];
    }
    
    $uploadedFiles = $_FILES['files'];
    $uploadedCount = 0;
    $errors = [];
    
    // Create uploads directory if it doesn't exist
    if (!is_dir('uploads') && !mkdir('uploads', 0755, true)) {
        return ['success' => false, 'message' => 'Cannot create uploads directory'];
    }
    
    for ($i = 0; $i < count($uploadedFiles['name']); $i++) {
        // Skip if no file was uploaded for this slot
        if ($uploadedFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        
        $fileName = basename($uploadedFiles['name'][$i]);
        $fileTmp = $uploadedFiles['tmp_name'][$i];
        $fileSize = $uploadedFiles['size'][$i];
        $fileError = $uploadedFiles['error'][$i];
        
        // Skip hidden files
        if (strpos($fileName, '.') === 0) {
            continue;
        }
        
        // Check upload error
        if ($fileError !== UPLOAD_ERR_OK) {
            $errors[] = "Error uploading $fileName: " . getUploadError($fileError);
            continue;
        }
        
        // Check file size
        if ($fileSize > $maxFileSize) {
            $errors[] = "File $fileName is too large (max 100MB)";
            continue;
        }
        
        // Check if file was actually uploaded
        if (!is_uploaded_file($fileTmp)) {
            $errors[] = "Possible file upload attack: $fileName";
            continue;
        }
        
        // Generate safe filename
        $safeFileName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName);
        $destination = 'uploads/' . $safeFileName;
        
        // Prevent overwriting
        $counter = 1;
        while (file_exists($destination)) {
            $pathinfo = pathinfo($safeFileName);
            $name = $pathinfo['filename'];
            $extension = isset($pathinfo['extension']) ? '.' . $pathinfo['extension'] : '';
            $safeFileName = $name . '_' . $counter . $extension;
            $destination = 'uploads/' . $safeFileName;
            $counter++;
        }
        
        // Move uploaded file
        if (move_uploaded_file($fileTmp, $destination)) {
            chmod($destination, 0644);
            $uploadedCount++;
        } else {
            $errors[] = "Failed to save file $fileName";
        }
    }
    
    if ($uploadedCount > 0) {
        // Redirect back with success message
        return ['success' => true, 'redirect' => '?upload=success&count=' . $uploadedCount];
    } else {
        $errorMsg = !empty($errors) ? implode(', ', $errors) : 'No files were uploaded';
        return ['success' => false, 'redirect' => '?upload=error&msg=' . urlencode($errorMsg)];
    }
}

// Get upload error message
function getUploadError($errorCode) {
    $errors = [
        UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize',
        UPLOAD_ERR_FORM_SIZE => 'File exceeds form MAX_FILE_SIZE',
        UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
        UPLOAD_ERR_NO_FILE => 'No file was uploaded',
        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
        UPLOAD_ERR_EXTENSION => 'PHP extension stopped the file upload'
    ];
    
    return $errors[$errorCode] ?? 'Unknown upload error';
}

// Get directory files
function getDirectoryFiles() {
    $files = [];
    $dirs = ['.', 'uploads'];
    
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) continue;
        
        $items = scandir($dir);
        
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item === 'index.php') {
                continue;
            }
            
            $path = $dir . '/' . $item;
            $relativePath = ($dir === '.') ? $item : $dir . '/' . $item;
            
            $files[] = [
                'name' => $item,
                'path' => $relativePath,
                'size' => is_dir($path) ? 0 : filesize($path),
                'is_dir' => is_dir($path),
                'modified' => filemtime($path),
                'is_hidden' => strpos($item, '.') === 0,
                'directory' => $dir
            ];
        }
    }
    
    // Sort: directories first, then files
    usort($files, function($a, $b) {
        if ($a['is_dir'] && !$b['is_dir']) return -1;
        if (!$a['is_dir'] && $b['is_dir']) return 1;
        return strcasecmp($a['name'], $b['name']);
    });
    
    return $files;
}

// Get file statistics
function getFileStats($files) {
    $totalSize = 0;
    $totalFiles = 0;
    $hiddenFiles = 0;
    
    foreach ($files as $file) {
        if ($file['is_hidden']) {
            $hiddenFiles++;
        } else {
            $totalFiles++;
            $totalSize += $file['size'];
        }
    }
    
    // Get free space
    $freeSpace = disk_free_space('.');
    
    return [
        'total_files' => $totalFiles,
        'hidden_files' => $hiddenFiles,
        'total_size' => $totalSize,
        'free_space' => $freeSpace
    ];
}

// Format file size
function formatFileSize($bytes) {
    if ($bytes === 0) return '0 B';
    
    $k = 1024;
    $sizes = ['B', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    
    return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}

// Get file icon
function getFileIcon($filename, $isDir) {
    if ($isDir) return '📁';
    
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    $icons = [
        // Images
        'jpg' => '🖼️', 'jpeg' => '🖼️', 'png' => '🖼️', 'gif' => '🖼️', 
        'svg' => '🖼️', 'bmp' => '🖼️', 'ico' => '🖼️', 'webp' => '🖼️',
        
        // Audio
        'mp3' => '🎵', 'wav' => '🎵', 'ogg' => '🎵', 'flac' => '🎵',
        'm4a' => '🎵', 'aac' => '🎵',
        
        // Video
        'mp4' => '🎬', 'avi' => '🎬', 'mov' => '🎬', 'mkv' => '🎬',
        'webm' => '🎬', 'flv' => '🎬', 'wmv' => '🎬',
        
        // Archives
        'zip' => '📦', 'rar' => '📦', '7z' => '📦', 'tar' => '📦',
        'gz' => '📦', 'bz2' => '📦',
        
        // Documents
        'pdf' => '📄', 'doc' => '📝', 'docx' => '📝', 'txt' => '📄',
        'rtf' => '📄', 'odt' => '📝', 'md' => '📄',
        
        // Spreadsheets
        'xls' => '📊', 'xlsx' => '📊', 'csv' => '📊',
        
        // Presentations
        'ppt' => '📽️', 'pptx' => '📽️',
        
        // Code
        'php' => '🐘', 'js' => '📜', 'html' => '🌐', 'htm' => '🌐',
        'css' => '🎨', 'py' => '🐍', 'java' => '☕', 'cpp' => '🔧',
        'c' => '🔧', 'json' => '📋', 'xml' => '📋', 'sql' => '🗄️',
        'sh' => '🐚', 'bash' => '🐚',
        
        // Default
        'default' => '📄'
    ];
    
    return $icons[$ext] ?? $icons['default'];
}

// Check for upload messages
$uploadMessage = '';
$uploadClass = '';
if (isset($_GET['upload'])) {
    if ($_GET['upload'] === 'success') {
        $count = $_GET['count'] ?? 1;
        $uploadMessage = "✅ Successfully uploaded $count file(s)";
        $uploadClass = 'success';
    } elseif ($_GET['upload'] === 'error') {
        $msg = $_GET['msg'] ?? 'Upload failed';
        $uploadMessage = "❌ " . htmlspecialchars($msg);
        $uploadClass = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚀 PHP File Server</title>
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --dark-bg: #0f172a;
            --dark-card: #1e293b;
            --dark-border: #334155;
            --text: #f1f5f9;
            --text-muted: #94a3b8;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        body {
            background: var(--dark-bg);
            color: var(--text);
            min-height: 100vh;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem;
        }
        
        /* Header */
        header {
            text-align: center;
            margin-bottom: 1.5rem;
            padding: 1.5rem;
            background: linear-gradient(135deg, var(--dark-card), #1e1b4b);
            border-radius: 12px;
            border: 1px solid var(--dark-border);
            position: relative;
        }
        
        header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }
        
        h1 {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 0.5rem;
        }
        
        .subtitle {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }
        
        .server-info {
            display: inline-flex;
            align-items: center;
            gap: 1rem;
            padding: 0.5rem 1rem;
            background: rgba(30, 41, 59, 0.6);
            border-radius: 8px;
            border: 1px solid var(--dark-border);
            font-size: 0.85rem;
        }
        
        
        /* Upload Message */
        .upload-message {
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            text-align: center;
            font-weight: 500;
            animation: slideIn 0.3s ease;
        }
        
        .upload-message.success {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--secondary);
        }
        
        .upload-message.error {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--danger);
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Main Layout */
        .main-layout {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        @media (max-width: 768px) {
            .main-layout {
                grid-template-columns: 1fr;
            }
        }
        
        /* Upload Section */
        .upload-section {
            background: var(--dark-card);
            border-radius: 12px;
            padding: 1rem;
            border: 1px solid var(--dark-border);
            height: fit-content;
        }
        
        .upload-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        
        .upload-zone {
            border: 2px dashed var(--dark-border);
            border-radius: 10px;
            padding: 2rem 1rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 1rem;
            position: relative;
            background: rgba(30, 41, 59, 0.4);
        }
        
        .upload-zone:hover {
            border-color: var(--primary);
            background: rgba(99, 102, 241, 0.1);
        }
        
        .upload-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            opacity: 0.8;
        }
        
        .upload-instructions {
            color: var(--text-muted);
            font-size: 0.8rem;
            margin-top: 0.25rem;
        }
        
        .file-input {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            opacity: 0;
            cursor: pointer;
        }
        
        .file-list {
            max-height: 150px;
            overflow-y: auto;
            margin: 0.75rem 0;
            font-size: 0.85rem;
        }
        
        .file-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem;
            background: rgba(15, 23, 42, 0.6);
            border-radius: 6px;
            margin-bottom: 0.25rem;
            border: 1px solid var(--dark-border);
        }
        
        .file-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            min-width: 0;
        }
        
        .file-item-icon {
            font-size: 0.9rem;
            flex-shrink: 0;
        }
        
        .file-item-name {
            font-size: 0.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 120px;
        }
        
        .upload-btn {
            width: 100%;
            padding: 0.75rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .upload-btn:hover:not(:disabled) {
            background: linear-gradient(135deg, var(--primary-dark), #4338ca);
        }
        
        .upload-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        /* Files Section */
        .files-section {
            background: var(--dark-card);
            border-radius: 12px;
            padding: 1rem;
            border: 1px solid var(--dark-border);
        }
        
        .files-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--dark-border);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        .stat-card {
            background: rgba(15, 23, 42, 0.6);
            padding: 0.75rem;
            border-radius: 8px;
            border: 1px solid var(--dark-border);
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }
        
        .total-files { color: var(--primary); }
        .total-size { color: var(--secondary); }
        .hidden-files { color: var(--warning); }
        .free-space { color: #8b5cf6; }
        
        /* Controls */
        .controls {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }
        
        .search-box {
            flex: 1;
            min-width: 200px;
            padding: 0.75rem 1rem;
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid var(--dark-border);
            border-radius: 8px;
            color: var(--text);
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }
        
        .search-box:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.1);
        }
        
        .control-btn {
            padding: 0.75rem 1rem;
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid var(--dark-border);
            border-radius: 8px;
            color: var(--text);
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }
        
        .control-btn:hover {
            background: rgba(99, 102, 241, 0.1);
            border-color: var(--primary);
        }
        
        /* File List View */
        .file-list-view {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .list-item {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            background: rgba(15, 23, 42, 0.4);
            border-radius: 8px;
            border: 1px solid var(--dark-border);
            transition: all 0.2s ease;
        }
        
        .list-item:hover {
            background: rgba(15, 23, 42, 0.6);
            border-color: var(--primary);
        }
        
        .list-icon {
            font-size: 1.25rem;
            width: 30px;
            text-align: center;
            flex-shrink: 0;
        }
        
        .list-info {
            flex: 1;
            min-width: 0;
            margin: 0 0.75rem;
        }
        
        .list-name {
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .list-meta {
            display: flex;
            gap: 1rem;
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        
        .list-actions {
            display: flex;
            gap: 0.5rem;
            flex-shrink: 0;
        }
        
        .list-action-btn {
            padding: 0.4rem 0.75rem;
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.2);
            border-radius: 6px;
            color: var(--primary);
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .list-action-btn:hover {
            background: rgba(99, 102, 241, 0.2);
        }
        
        .list-action-btn.open {
            background: rgba(16, 185, 129, 0.1);
            border-color: rgba(16, 185, 129, 0.2);
            color: var(--secondary);
        }
        
        .list-action-btn.open:hover {
            background: rgba(16, 185, 129, 0.2);
        }
        
        /* Empty States */
        .empty-state {
            text-align: center;
            padding: 2rem 1rem;
            color: var(--text-muted);
        }
        
        .empty-icon {
            font-size: 2rem;
            margin-bottom: 0.75rem;
            opacity: 0.5;
        }
        
        /* Footer */
        footer {
            text-align: center;
            padding: 1rem;
            color: var(--text-muted);
            font-size: 0.8rem;
            border-top: 1px solid var(--dark-border);
            margin-top: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🚀 PHP File Server</h1>
            <p class="subtitle">Simple file server</p>
            </div>
        </header>
        
        <?php if ($uploadMessage): ?>
            <div class="upload-message <?php echo $uploadClass; ?>">
                <?php echo $uploadMessage; ?>
            </div>
        <?php endif; ?>
        
        <div class="main-layout">
            <!-- Upload Section -->
            <div class="upload-section">
                <div class="upload-header">
                    <div style="font-size: 1.25rem;">📤</div>
                    <h2 style="color: var(--text); font-size: 1.1rem;">Upload Files</h2>
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="upload-zone" onclick="document.getElementById('fileInput').click()">
                        <div class="upload-icon">⬆️</div>
                        <h3 style="margin-bottom: 0.5rem; color: var(--text); font-size: 0.95rem;">Click to Select Files</h3>
                        <p class="upload-instructions">Max file size: 100MB per file</p>
                        <p class="upload-instructions" style="color: var(--warning); margin-top: 0.5rem;">
                            Files are saved to "uploads/" folder
                        </p>
                        <input type="file" id="fileInput" name="files[]" multiple style="display: none;">
                    </div>
                    
                    <div id="selectedFiles" class="file-list">
                        <!-- Files will be displayed here by JavaScript -->
                    </div>
                    
                    <button type="submit" class="upload-btn">
                        <span>📤 Upload Files</span>
                    </button>
                </form>
                
                <div style="margin-top: 1rem; font-size: 0.8rem; color: var(--text-muted);">
                    <p><strong>Note:</strong> PHP built-in server supports uploads up to 2GB by default.</p>
                </div>
            </div>
            
            <!-- Files Section -->
            <div class="files-section">
                <div class="files-header">
                    <h2 style="color: var(--text); font-size: 1.1rem;">Files in Directory</h2>
                    <button class="control-btn" onclick="location.reload()">
                        <span>🔄</span>
                        Refresh
                    </button>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number total-files"><?php echo $stats['total_files']; ?></div>
                        <div>Files</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number total-size"><?php echo formatFileSize($stats['total_size']); ?></div>
                        <div>Total Size</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number hidden-files"><?php echo $stats['hidden_files']; ?></div>
                        <div>Hidden</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number free-space"><?php echo formatFileSize($stats['free_space']); ?></div>
                        <div>Free Space</div>
                    </div>
                </div>
                
                <div class="controls">
                    <input type="text" class="search-box" id="searchInput" placeholder="🔍 Search files..." onkeyup="filterFiles()">
                </div>
                
                <div class="file-list-view" id="filesList">
                    <?php if (empty($files)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📂</div>
                            <h3 style="margin-bottom: 0.5rem;">No files found</h3>
                            <p>This directory is empty. Upload some files to get started.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($files as $file): ?>
                            <?php if (!$file['is_hidden']): ?>
                                <div class="list-item" data-name="<?php echo htmlspecialchars($file['name']); ?>">
                                    <div class="list-icon"><?php echo getFileIcon($file['name'], $file['is_dir']); ?></div>
                                    <div class="list-info">
                                        <div class="list-name" title="<?php echo htmlspecialchars($file['name']); ?>">
                                            <?php echo htmlspecialchars($file['name']); ?>
                                            <?php if ($file['directory'] === 'uploads'): ?>
                                                <span style="font-size: 0.7rem; color: var(--warning); margin-left: 0.5rem;">(uploaded)</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="list-meta">
                                            <span><?php echo $file['is_dir'] ? 'Folder' : formatFileSize($file['size']); ?></span>
                                            <span>Modified: <?php echo date('Y-m-d H:i', $file['modified']); ?></span>
                                        </div>
                                    </div>
                                    <div class="list-actions">
                                        <?php if ($file['is_dir']): ?>
                                            <a href="<?php echo htmlspecialchars($file['path']); ?>/" class="list-action-btn open">
                                                <span>📁</span>
                                                Open
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo htmlspecialchars($file['path']); ?>" class="list-action-btn" download>
                                                <span>⬇️</span>
                                                Download
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <footer>
            <p>PHP File Server • Running on PHP <?php echo PHP_VERSION; ?> Built-in Server</p>
            <p style="margin-top: 0.5rem; color: var(--text-muted);">
                Last updated: <?php echo date('Y-m-d H:i:s'); ?>
            </p>
        </footer>
    </div>
    
    <script>
        // Show selected files
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const container = document.getElementById('selectedFiles');
            container.innerHTML = '';
            
            if (this.files.length === 0) {
                container.innerHTML = '<div style="color: var(--text-muted); text-align: center; padding: 0.5rem;">No files selected</div>';
                return;
            }
            
            Array.from(this.files).forEach(file => {
                const div = document.createElement('div');
                div.className = 'file-item';
                div.innerHTML = `
                    <div class="file-info">
                        <div class="file-item-icon">📄</div>
                        <div>
                            <div class="file-item-name" title="${file.name}">${file.name}</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted);">${formatFileSize(file.size)}</div>
                        </div>
                    </div>
                `;
                container.appendChild(div);
            });
        });
        
        // Filter files
        function filterFiles() {
            const search = document.getElementById('searchInput').value.toLowerCase();
            const items = document.querySelectorAll('.list-item');
            
            items.forEach(item => {
                const name = item.getAttribute('data-name').toLowerCase();
                if (name.includes(search)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        }
        
        // Format file size
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 B';
            
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        // Drag and drop
        const uploadZone = document.querySelector('.upload-zone');
        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.style.borderColor = 'var(--primary)';
            uploadZone.style.backgroundColor = 'rgba(99, 102, 241, 0.1)';
        });
        
        uploadZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadZone.style.borderColor = 'var(--dark-border)';
            uploadZone.style.backgroundColor = 'rgba(30, 41, 59, 0.4)';
        });
        
        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.style.borderColor = 'var(--dark-border)';
            uploadZone.style.backgroundColor = 'rgba(30, 41, 59, 0.4)';
            
            const files = e.dataTransfer.files;
            const fileInput = document.getElementById('fileInput');
            
            // Create a new DataTransfer object
            const dataTransfer = new DataTransfer();
            
            // Add existing files
            for (let i = 0; i < fileInput.files.length; i++) {
                dataTransfer.items.add(fileInput.files[i]);
            }
            
            // Add new files
            for (let i = 0; i < files.length; i++) {
                dataTransfer.items.add(files[i]);
            }
            
            // Assign back to file input
            fileInput.files = dataTransfer.files;
            
            // Trigger change event
            fileInput.dispatchEvent(new Event('change'));
        });
    </script>
</body>
</html>
