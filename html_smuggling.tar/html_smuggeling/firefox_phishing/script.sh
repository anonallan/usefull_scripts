#!/usr/bin/env	bash

touch /var/log/phishing_creds.log
touch /var/log/keystrokes.log
sudo chmod 666 /var/log/keystrokes.log /var/log/phishing_creds.log

