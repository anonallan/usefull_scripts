Sserver.tar , is upload page made for php servers like apache and ngins , php -S 0.0.0.0:8080 , but just for downloading , because simple php server dosn't support uploads (POST Requests)
